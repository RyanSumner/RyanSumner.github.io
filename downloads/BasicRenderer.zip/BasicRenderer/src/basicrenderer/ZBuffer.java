package basicrenderer;

import java.awt.Color;
import java.util.LinkedList;

/**
 *
 * @author Ryan Sumner
 */
public class ZBuffer {
    private int imageHeight;
    private int imageWidth;
    private Color[][] bitmap;
    private float[][] depth;
    private LinkedList<Polygon> polygons;
    private Vector3D originalLight;
    private Vector3D viewingLight;
    private Vector3D light;
    private float maxX;
    private float minX;
    private float maxY;
    private float minY;
    private float ar,ag,ab,Ir,Ig,Ib;
    private static final float DegToRad = (float)(Math.PI / 180);
    private static final float RadToDeg = (float)(180 / Math.PI);
     
    public ZBuffer(int imageHeight, int imageWidth, Converter converter){
        this.imageHeight = imageHeight;
        this.imageWidth = imageWidth;
        originalLight = converter.getLight();
        viewingLight = originalLight;
        light = viewingLight;
        maxX = Float.NEGATIVE_INFINITY;
        minX = Float.POSITIVE_INFINITY;
        maxY = Float.NEGATIVE_INFINITY;
        minY = Float.POSITIVE_INFINITY;
        ar = 0.5f; 
        ab = 0.5f; 
        ag = 0.5f;
        Ir = 1.0f; 
        Ib = 1.0f;
        Ig = 1.0f;
        initializeBuffer();
        initializePolygons(converter);   
    }
      
    public void printDepth(){
        for (int row = 0; row < imageHeight; row++){
            for (int col = 0; col < imageWidth; col++){ 
                if(depth[col][row]==Float.POSITIVE_INFINITY){
                    System.out.print("I");
                }
                else{
                    System.out.print("C");
                }
            }
            System.out.println();
        }
    }
    
    public void printBitmap(){
        for (int row = 0; row < imageHeight; row++){
            for (int col = 0; col < imageWidth; col++){ 
                if(bitmap[col][row].equals(Color.GRAY)){
                    System.out.print("W");
                } else if(bitmap[col][row].equals(new Color(200,210,0))){
                    System.out.print("E");
                }
                else{
                    System.out.print("C");
                }
            }
            System.out.println(" "+row);
        }
    }
    
    public void calculateBuffer(){
        initializeBuffer();
        
        float scaleFactorX = calculateScaleX();
        float scaleFactorY = calculateScaleY();
        float transX = calculateTransX(scaleFactorX);
        float transY = calculateTransY(scaleFactorY);
        
        maxX = Float.NEGATIVE_INFINITY;
        minX = Float.POSITIVE_INFINITY;
        maxY = Float.NEGATIVE_INFINITY;
        minY = Float.POSITIVE_INFINITY;
        
        for (Polygon poly : polygons) {
            
            if((scaleFactorX!=1)||(scaleFactorY!=1)){ //if scaling is needed, scale it
                Transform scaleTrans = Transform.newScale(scaleFactorX,scaleFactorY,1);
                poly.vertices[0] = scaleTrans.multiply(poly.vertices[0]);
                poly.vertices[1] = scaleTrans.multiply(poly.vertices[1]);
                poly.vertices[2] = scaleTrans.multiply(poly.vertices[2]);
            }
            
            if((transX!=0)||(transY!=0)){// translate the bounding box so that the top left of the box is at position x = 0, y = 0
                Transform translateTrans = Transform.newTranslation(transX, transY, 0);
                poly.vertices[0] = translateTrans.multiply(poly.vertices[0]);
                poly.vertices[1] = translateTrans.multiply(poly.vertices[1]);
                poly.vertices[2] = translateTrans.multiply(poly.vertices[2]);
            }

            poly.recalculateMinMax();

            maxX = Math.max(maxX, poly.maxX);
            minX = Math.min(minX, poly.minX);
            maxY = Math.max(maxY, poly.maxY);
            minY = Math.min(minY, poly.minY);
        }
        
        for (Polygon poly : polygons) {

            float x1 = poly.vertices[0].x;
            float x2 = poly.vertices[1].x;
            float x3 = poly.vertices[2].x;
            float y1 = poly.vertices[0].y;
            float y2 = poly.vertices[1].y;
            float y3 = poly.vertices[2].y;
            
            if(!((x2-x1)*(y3-y2) > (y2-y1)*(x3-x2))){ //do not render hidden polygons
                poly.calculateEdgeList(imageHeight,imageWidth);
                
                poly.calculateNormal();
                poly.computeNewRGB(light,ar,ag,ab,Ir,Ig,Ib);
            
                for (int y = 0; y < imageHeight-1; y++) {
                    int x = Math.round(poly.getEdgeListXL(y));
                    float z = poly.getEdgeListZL(y);
                    float xRight = poly.getEdgeListXR(y);
                    float mz = (poly.getEdgeListZR(y) - poly.getEdgeListZL(y))
                                /(xRight - poly.getEdgeListXL(y));
                    while(x<=Math.round(xRight)){
                        if(z < depth[x][y]){
                            if(x < imageWidth){
                                depth[x][y] = z;
                                bitmap[x][y] = new Color(poly.newRGB[0],poly.newRGB[1],poly.newRGB[2]);
                            }
                        }
                        x++;
                        z+=mz;
                    }  
                }
            }
        }
    }
    
    public void newViewingDirection(Vector3D newView){
  
        float x = newView.x;
        float y = newView.y;
		float z = newView.z;

		float yz;
		float xyz;

		if((y==0)&&(z==0)){
			yz = 0;
		} else {
			yz = (float)(y/Math.sqrt((y*y)+(z*z)));
		}

		if((x==0)&&(y==0)&&(z==0)){
			xyz = 0;
		} else{
			xyz = (float)(-x/Math.sqrt((x*x)+(y*y)+(z*z)));
		}

		float xRot = (float)Math.asin(yz)*RadToDeg;
		float yRot = (float)Math.asin(xyz)*RadToDeg;
			
		if(z<0){
			yRot=180-yRot;
		}
        
        maxX = Float.NEGATIVE_INFINITY;
        minX = Float.POSITIVE_INFINITY;
        maxY = Float.NEGATIVE_INFINITY;
        minY = Float.POSITIVE_INFINITY;
        
        if((yRot!=0)||(xRot!=0)){   
            Transform rotYTrans = Transform.newYRotation(yRot*DegToRad);
            Transform rotXTrans = Transform.newXRotation(xRot*DegToRad);
            Transform rotXYTrans = rotXTrans.compose(rotYTrans);
            viewingLight = rotXYTrans.multiply(originalLight);
            light = viewingLight;
            
            for (Polygon poly : polygons) {
                Vertex[] tempV = new Vertex[3];
                
                tempV[0] = rotXYTrans.multiply(poly.originalVertices[0]);
                tempV[1] = rotXYTrans.multiply(poly.originalVertices[1]);
                tempV[2] = rotXYTrans.multiply(poly.originalVertices[2]);
                
                System.arraycopy(tempV, 0, poly.viewingVertices, 0, tempV.length);
                System.arraycopy(tempV, 0, poly.vertices, 0, tempV.length);

                poly.recalculateMinMax();

                maxX = Math.max(maxX, poly.maxX);
                minX = Math.min(minX, poly.minX);
                maxY = Math.max(maxY, poly.maxY);
                minY = Math.min(minY, poly.minY);
            }
        } else {
            viewingLight = originalLight;
            light = originalLight;
            for (Polygon poly : polygons) {
                
                System.arraycopy(poly.originalVertices, 0, poly.viewingVertices, 0, poly.originalVertices.length);
                System.arraycopy(poly.originalVertices, 0, poly.vertices, 0, poly.originalVertices.length);
                
                poly.recalculateMinMax();

                maxX = Math.max(maxX, poly.maxX);
                minX = Math.min(minX, poly.minX);
                maxY = Math.max(maxY, poly.maxY);
                minY = Math.min(minY, poly.minY);
            }
        }
    }
    
    public void calculateXYRotation(float rotX, float rotY){
        maxX = Float.NEGATIVE_INFINITY;
        minX = Float.POSITIVE_INFINITY;
        maxY = Float.NEGATIVE_INFINITY;
        minY = Float.POSITIVE_INFINITY;
        
        if((rotY!=0)||(rotX!=0)){   
            Transform rotYTrans = Transform.newYRotation(rotY*DegToRad);
            Transform rotXTrans = Transform.newXRotation(rotX*DegToRad);
            Transform rotXYTrans = rotXTrans.compose(rotYTrans);
            light = rotXYTrans.multiply(viewingLight);
            
            for (Polygon poly : polygons) {

                poly.vertices[0] = rotXYTrans.multiply(poly.viewingVertices[0]);
                poly.vertices[1] = rotXYTrans.multiply(poly.viewingVertices[1]);
                poly.vertices[2] = rotXYTrans.multiply(poly.viewingVertices[2]); 
                
                poly.recalculateMinMax();

                maxX = Math.max(maxX, poly.maxX);
                minX = Math.min(minX, poly.minX);
                maxY = Math.max(maxY, poly.maxY);
                minY = Math.min(minY, poly.minY);
            }
        } else {
            light = viewingLight;
            for (Polygon poly : polygons) {                
                System.arraycopy(poly.viewingVertices, 0, poly.vertices, 0, poly.viewingVertices.length);
                
                poly.recalculateMinMax();

                maxX = Math.max(maxX, poly.maxX);
                minX = Math.min(minX, poly.minX);
                maxY = Math.max(maxY, poly.maxY);
                minY = Math.min(minY, poly.minY);
            }
        }
    }
    
    public Color[][] getBitmap(){return bitmap;}
    
    public void setOriginalLight(Vector3D newLight){
        if((newLight.x != 0)||(newLight.y != 0)||(newLight.z != 0)){
            viewingLight = newLight;
        }  
    }
    
    public void setAR(float ar){this.ar = ar;}
    public void setAG(float ag){this.ag = ag;}
    public void setAB(float ab){this.ab = ab;}
    public void setIR(float Ir){this.Ir = Ir;}
    public void setIB(float Ib){this.Ib = Ib;}
    public void setIG(float Ig){this.Ig = Ig;}
    
    private void initializeBuffer(){
        bitmap = new Color[imageWidth][imageHeight];
        depth = new float[imageWidth][imageHeight];
        
        for (int row = 0; row < imageHeight; row++) 
            for (int col = 0; col < imageWidth; col++) 
                bitmap[col][row] = Color.GRAY; //default colour
                   
        for (int row = 0; row < imageHeight; row++) 
            for (int col = 0; col < imageWidth; col++) 
                depth[col][row] = Float.POSITIVE_INFINITY; 
    }
    
    private void initializePolygons(Converter converter){
        polygons = new LinkedList<>();
        while(converter.hasCurrentPolygon()){
            Vertex[] currentVertices = converter.getCurrentVertices();
            int[] currentRGB = converter.getCurrentRGB();
            Polygon currentPolygon = new Polygon(currentVertices,currentRGB);
            maxX = Math.max(maxX, currentPolygon.maxX);
            minX = Math.min(minX, currentPolygon.minX);
            maxY = Math.max(maxY, currentPolygon.maxY);
            minY = Math.min(minY, currentPolygon.minY);
            polygons.add(currentPolygon);
            converter.nextPolygon();
        }
    }
    
    private float calculateScaleX(){
        if((imageWidth-1)<(maxX-minX))
            return (imageWidth-1)/(maxX-minX);
        else
            return 1;
    }
    
    private float calculateScaleY(){
        if((imageHeight-1)<(maxY-minY))
            return (imageHeight-1)/(maxY-minY);
        else
            return 1;
    }
    
    private float calculateTransX(float scalefactor){
        float transX = 0;
        float currentMinX = minX * scalefactor;
        if(currentMinX != 0)
            transX = 0 - currentMinX;
        return transX;
    }
    
    private float calculateTransY(float scalefactor){
        float transY = 0;
        float currentMinY = minY * scalefactor;
        if(currentMinY != 0)
            transY = 0 - currentMinY;
        return transY;
    }
}   
