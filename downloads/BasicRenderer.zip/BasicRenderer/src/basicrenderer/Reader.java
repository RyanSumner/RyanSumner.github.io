package basicrenderer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
/**
 *
 * @author Ryan Sumner
 */

public class Reader {
    String filePath;
    
    public Reader(String filePath){
        this.filePath = filePath;        
    }
    
    public Converter read()throws FileNotFoundException, IOException{
        LinkedList<String> info = readFile(filePath);

        Converter converter = new Converter();
        
        converter.initialize(info);
        
        return converter;
    }

    private LinkedList<String> readFile(String filePath) throws FileNotFoundException, IOException{
        LinkedList<String> input = new LinkedList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader (new File (filePath)))) {
            String current = reader.readLine();
            while(current!=null){
                input.add(current);
                current = reader.readLine();
            }
        }
        return input;
    }
    
}