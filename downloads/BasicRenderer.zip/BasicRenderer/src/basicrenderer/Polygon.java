package basicrenderer;

/**
 *
 * @author Ryan Sumner
 */
public class Polygon {
    public Vertex[] viewingVertices;
    public Vertex[] originalVertices;
    public Vertex[] vertices;
    public int[] originalRGB;
    public int[] newRGB;
    private EdgeList[] edgeList;
    private Vector3D normal;
    public float maxX;
    public float minX;
    public float maxY;
    public float minY;
        
    public Polygon(Vertex[] vertices, int[] rgb){
        this.vertices = vertices;
        viewingVertices = new Vertex[3];
        originalVertices = new Vertex[3];
        System.arraycopy(vertices, 0, viewingVertices, 0, vertices.length);
        System.arraycopy(vertices, 0, originalVertices, 0, vertices.length);
        this.originalRGB = rgb;
        calculateNormal();
        maxX = calculateMaxX();
        minX = calculateMinX();
        maxY = calculateMaxY();
        minY = calculateMinY();
    }
    
    public void recalculateMinMax(){
        maxX = calculateMaxX();
        minX = calculateMinX();
        maxY = calculateMaxY();
        minY = calculateMinY();
    }
    
    public void calculateEdgeList(int imageHeight, int imageWidth){
        edgeList = new EdgeList[imageHeight];
        
        for (int i = 0; i < imageHeight; i++) {
            edgeList[i] = new EdgeList(Float.POSITIVE_INFINITY, 
                                       Float.POSITIVE_INFINITY, 
                                       Float.NEGATIVE_INFINITY, 
                                       Float.POSITIVE_INFINITY);
        }
        CalcEdge(vertices[0],vertices[1]);
        CalcEdge(vertices[1],vertices[2]);
        CalcEdge(vertices[2],vertices[0]);
        
    }
    
    public void computeNewRGB(Vector3D light, float ar, float ag, float ab, float Ir, float Ig, float Ib){
        newRGB = new int[3];
        
        Vector3D unitLight = light.unitVector();
        Vector3D unitNormal = normal.unitVector();

        float costh = unitLight.dotProduct(unitNormal);
        
        newRGB[0] = Math.round((ar + Ir * costh) * originalRGB[0]);
        newRGB[1] = Math.round((ag + Ig * costh) * originalRGB[1]);
        newRGB[2] = Math.round((ab + Ib * costh) * originalRGB[2]);

        if(newRGB[0]>255)
            newRGB[0]=255;
        if(newRGB[0]<0)
            newRGB[0]=0;
        
        if(newRGB[1]>255)
            newRGB[1]=255;
        if(newRGB[1]<0)
            newRGB[1]=0;
        
        if(newRGB[2]>255)
            newRGB[2]=255;
        if(newRGB[2]<0)
            newRGB[2]=0;

    }
    
    public void calculateNormal(){
        Vector3D U = new Vector3D(vertices[1].x - vertices[0].x, vertices[1].y - vertices[0].y, vertices[1].z - vertices[0].z);
        Vector3D V = new Vector3D(vertices[2].x - vertices[0].x, vertices[2].y - vertices[0].y, vertices[2].z - vertices[0].z);
        normal = U.crossProduct(V);
    }
    
    public void printEdgeList(){
        for (int i = 0; i < edgeList.length; i++) {
            System.out.println("y = "+i+": "+edgeList[i].xl+" "+edgeList[i].zl+" "+edgeList[i].xr+" "+edgeList[i].zr);   
        }
    }
    
    public void printVertices(){
        System.out.println(vertices[0].x + " " + vertices[0].y + " " + vertices[0].z);
        System.out.println(vertices[1].x + " " + vertices[1].y + " " + vertices[1].z);
        System.out.println(vertices[2].x + " " + vertices[2].y + " " + vertices[2].z);
        System.out.println();
    }
    
    public float getEdgeListXL(int y){return edgeList[y].xl;}
    public float getEdgeListZL(int y){return edgeList[y].zl;}
    public float getEdgeListXR(int y){return edgeList[y].xr;}
    public float getEdgeListZR(int y){return edgeList[y].zr;}
    
    private void CalcEdge(Vertex v1, Vertex v2){
        Vertex vA; //vA is the vertex with the smallest y value.
        Vertex vB;
        
        if(v1.y<v2.y){
            vA = v1;
            vB = v2;
        } else {
            vA = v2;
            vB = v1;
        }
        
        float mx = (vB.x - vA.x)/(vB.y - vA.y);
        float mz = (vB.z - vA.z)/(vB.y - vA.y);
        
        float currentX = vA.x;
        float currentZ = vA.z;
        
        int i = Math.round(vA.y);
        
        int maxi = Math.round(vB.y);
        
        while(i < maxi){

            if(currentX<edgeList[i].xl){
                edgeList[i].xl = currentX;
                edgeList[i].zl = currentZ;
            }
            if(currentX>edgeList[i].xr){
                edgeList[i].xr = currentX;
                edgeList[i].zr = currentZ;
            }

            currentX+=mx;
            currentZ+=mz;
            i++;
        }
        
        if(vB.x<edgeList[maxi].xl){
                edgeList[maxi].xl = vB.x;
                edgeList[maxi].zl = vB.z;
        }
        if(vB.x>edgeList[maxi].xr){
                edgeList[maxi].xr = vB.x;
                edgeList[maxi].zr = vB.z;
        }

    }
    
    private float calculateMaxY(){
        return Math.max(Math.max(vertices[0].y, vertices[1].y), vertices[2].y);
    }
    
    private float calculateMinY(){
        return Math.min(Math.min(vertices[0].y, vertices[1].y), vertices[2].y);
    }
    
    private float calculateMaxX(){
        return Math.max(Math.max(vertices[0].x, vertices[1].x), vertices[2].x);
    }
    
    private float calculateMinX(){
        return Math.min(Math.min(vertices[0].x, vertices[1].x), vertices[2].x);
    } 
        
    private class EdgeList{
        public float xl;
        public float zl;
        public float xr;
        public float zr;
        
        public EdgeList(float xl, float zl, float xr, float zr){
            this.xl = xl;
            this.zl = zl;
            this.xr = xr;
            this.zr = zr;
        }
    }
}
