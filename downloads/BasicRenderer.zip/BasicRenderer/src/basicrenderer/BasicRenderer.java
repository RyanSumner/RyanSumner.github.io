package basicrenderer;

import java.io.File;
import java.io.IOException;
import javax.swing.JComponent;
import javax.swing.*;
import java.awt.Graphics;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class BasicRenderer{
    
    private int imageWidth = 800;
    private int imageHeight = 800;
    
    private JFrame frame;
    private BufferedImage image;
    private JComponent drawing;
    private JTextArea textOutput;
    
    private JTextField viewX;
    private JTextField viewY;
    private JTextField viewZ;
    
    private JTextField lightX;
    private JTextField lightY;
    private JTextField lightZ;
    
    private JTextField lightAR;
    private JTextField lightAG;
    private JTextField lightAB;
    private JTextField lightIR;
    private JTextField lightIG;
    private JTextField lightIB;
    
    private float rotX = 0.0f;
    private float rotY = 0.0f;
    
    private ZBuffer zbuffer;

    public static void main(String[] args){
		new BasicRenderer();
    }
    
    private BasicRenderer(){     
		setupFrame();
		textOutput.setText("Click Open to Open the Selected DataFile \nUse left, right, up, down arrows to rotate the image\n");
    }

    private void createImage(){
        zbuffer.calculateBuffer();
        Color[][] bitmap = zbuffer.getBitmap();

		convertBitmapToImage(bitmap);
		drawing.repaint();
    }

    /** Converts a 2D array of Colors to a BufferedImage.
        Assumes that bitmap is indexed by column then row and has
	imageHeight rows and imageWidth columns.
	Note that image.setRGB requires x (col) and y (row) are given in that order.
    */
    private BufferedImage convertBitmapToImage(Color[][] bitmap) {
		image = new BufferedImage(imageWidth, imageHeight, BufferedImage.TYPE_INT_RGB);
		for (int x = 0; x < imageWidth; x++) {
			for (int y = 0; y < imageHeight; y++) {
			image.setRGB(x, y, bitmap[x][y].getRGB());
			}
		}
		return image;
    }

    /** writes the current image to a file of the specified name
    */ 
    private void saveImage(String fname){
		try {ImageIO.write(image, "png", new File(fname));}
		catch(IOException e){System.out.println("Image saving failed: "+e);}
    }

    /** Creates a frame with a JComponent in it.
     *  Clicking in the frame will close it. */
    private void setupFrame(){
		frame = new JFrame("Graphics Example");
		frame.setSize(imageWidth+400, imageHeight+200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		drawing = new JComponent(){
		protected void paintComponent(Graphics g){
			g.drawImage(image, 0, 0, null);}
		};
		frame.add(drawing, BorderLayout.CENTER);

		JPanel panel = new JPanel();
		frame.add(panel, BorderLayout.NORTH);
			
		addButton("Open", panel, new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				JFileChooser chooser=new  JFileChooser();
				int returnVal = chooser.showOpenDialog(null);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					String filePath = chooser.getSelectedFile().getAbsoluteFile().toString();
					Reader reader = new Reader(filePath);
					Converter converter = new Converter();
					try {
						converter = reader.read();
					} catch (FileNotFoundException ex) {
						Logger.getLogger(BasicRenderer.class.getName()).log(Level.SEVERE, null, ex);
					} catch (IOException ex) {
						Logger.getLogger(BasicRenderer.class.getName()).log(Level.SEVERE, null, ex);
					}
					zbuffer = new ZBuffer(imageHeight, imageWidth, converter);
					createImage();}}});
		
		addButton("Save", panel, new ActionListener(){
			public void actionPerformed(ActionEvent ev){saveImage("TestImage.png");}});
		addButton("Quit", panel, new ActionListener(){
			public void actionPerformed(ActionEvent ev){System.exit(0);}});

		// make the arrow keys shift the image
		InputMap iMap = drawing.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
		ActionMap aMap= drawing.getActionMap();
		iMap.put(KeyStroke.getKeyStroke("LEFT"), "RotateLeft");
		iMap.put(KeyStroke.getKeyStroke("RIGHT"), "RotateRight");
		iMap.put(KeyStroke.getKeyStroke("UP"), "RotateUp");
		iMap.put(KeyStroke.getKeyStroke("DOWN"), "RotateDown");
		
		aMap.put("RotateLeft", new AbstractAction(){
			public void actionPerformed(ActionEvent e){
						if(zbuffer!=null){
							rotY-=45;
							if((rotY==360)||(rotY==-360))
								rotY=0;
							zbuffer.calculateXYRotation(rotX,rotY);
							createImage();}}});
		aMap.put("RotateRight", new AbstractAction(){
			public void actionPerformed(ActionEvent e){
						if(zbuffer!=null){
							rotY+=45;
							if((rotY==360)||(rotY==-360))
								rotY=0;
							zbuffer.calculateXYRotation(rotX,rotY);
							createImage();}}});
		aMap.put("RotateUp", new AbstractAction(){
			public void actionPerformed(ActionEvent e){
						if(zbuffer!=null){
							rotX-=45;
							if((rotX==360)||(rotX==-360))
								rotX=0;
							zbuffer.calculateXYRotation(rotX,rotY);
							createImage();}}});
		aMap.put("RotateDown", new AbstractAction(){
			public void actionPerformed(ActionEvent e){
						if(zbuffer!=null){
							rotX+=45;
							if((rotX==360)||(rotX==-360))
								rotX=0;
							zbuffer.calculateXYRotation(rotX,rotY);
							createImage();}}});

		textOutput = new JTextArea(4, 100);
		textOutput.setEditable(false);
		JScrollPane textSP = new JScrollPane(textOutput);
		frame.add(textSP, BorderLayout.SOUTH);
			
		JPanel pnlW = new JPanel(new GridLayout(4, 1));
		JPanel inner1 = new JPanel (new FlowLayout());
		JPanel inner2 = new JPanel (new FlowLayout());
		JPanel inner3 = new JPanel (new FlowLayout());
		JPanel inner4 = new JPanel (new FlowLayout());
			
		viewX = new JTextField(5);
		viewY = new JTextField(5);
		viewZ = new JTextField(5);
		inner1.add(viewX);
		inner1.add(viewY);
		inner1.add(viewZ);
		addButton("Set Viewing Direction", inner1, new ActionListener(){
			public void actionPerformed(ActionEvent ev){
						String xString = viewX.getText();
						String yString = viewY.getText();
						String zString = viewZ.getText();
						if((!xString.equals(""))&&(!yString.equals(""))&&(!zString.equals(""))){
							try {
								float X = Float.parseFloat(xString);
								float Y = Float.parseFloat(yString);
								float Z = Float.parseFloat(zString);
								if(zbuffer!=null){
									zbuffer.newViewingDirection(new Vector3D(X,Y,Z));
									rotY = 0;
									rotX = 0;
									createImage();
								}                        
							} catch (NumberFormatException ex) {
								//Not an float
							}
						}}});
			
			lightX = new JTextField(5);
			lightY = new JTextField(5);
			lightZ = new JTextField(5);
			inner2.add(lightX);
			inner2.add(lightY);
			inner2.add(lightZ);
			addButton("Set Light Direction", inner2, new ActionListener(){
				public void actionPerformed(ActionEvent ev){
							String xString = lightX.getText();
							String yString = lightY.getText();
							String zString = lightZ.getText();
							if((!xString.equals(""))&&(!yString.equals(""))&&(!zString.equals(""))){
								try {
									float X = Float.parseFloat(xString);
									float Y = Float.parseFloat(yString);
									float Z = Float.parseFloat(zString);
									if(zbuffer!=null){
										zbuffer.setOriginalLight(new Vector3D(-X,-Y,-Z));
										zbuffer.calculateXYRotation(rotX,rotY);
										createImage();
									}                        
								} catch (NumberFormatException ex) {
									//Not an float
								}
							}}});
			   
			lightAR = new JTextField(5);
			lightAG = new JTextField(5);
			lightAB = new JTextField(5);
			inner3.add(lightAR);
			inner3.add(lightAG);
			inner3.add(lightAB);
			addButton("Set Ambient Light", inner3, new ActionListener(){
				public void actionPerformed(ActionEvent ev){
							String arString = lightAR.getText();
							String agString = lightAG.getText();
							String abString = lightAB.getText();
							if((!arString.equals(""))&&(!agString.equals(""))&&(!abString.equals(""))){
								try {
									float AR = Float.parseFloat(arString);
									float AG = Float.parseFloat(agString);
									float AB = Float.parseFloat(abString);
									if(zbuffer!=null){
										zbuffer.setAR(AR);
										zbuffer.setAG(AG);
										zbuffer.setAB(AB);
										zbuffer.calculateXYRotation(rotX,rotY);
										createImage();
									}                        
								} catch (NumberFormatException ex) {
									//Not an float
								}
							}}});
			
			lightIR = new JTextField(5);
			lightIG = new JTextField(5);
			lightIB = new JTextField(5);
			inner4.add(lightIR);
			inner4.add(lightIG);
			inner4.add(lightIB);
			addButton("Set Light Intensity", inner4, new ActionListener(){
				public void actionPerformed(ActionEvent ev){
					String irString = lightIR.getText();
					String igString = lightIG.getText();
					String ibString = lightIB.getText();
					if((!irString.equals(""))&&(!igString.equals(""))&&(!ibString.equals(""))){
						try {
							float IR = Float.parseFloat(irString);
							float IG = Float.parseFloat(igString);
							float IB = Float.parseFloat(ibString);
							if(zbuffer!=null){
								zbuffer.setIR(IR);
								zbuffer.setIG(IG);
								zbuffer.setIB(IB);
								zbuffer.calculateXYRotation(rotX,rotY);
								createImage();
							}                        
						} catch (NumberFormatException ex) {
							//Not an float
						}
					}}});
			
			pnlW.add(inner1);
			pnlW.add(inner2);
			pnlW.add(inner3);
			pnlW.add(inner4);
			
		frame.add(pnlW, BorderLayout.WEST);

		frame.setVisible(true);
    }	
    
    private void addButton(String name, JComponent comp, ActionListener listener){
		JButton button = new JButton(name);
		comp.add(button);
		button.addActionListener(listener);
    }

}





