package basicrenderer;

import java.util.LinkedList;

/**
 *
 * @author Ryan Sumner
 */
public class Converter {
    private LinkedList<Polygon> polygons;
    private Polygon currentPolygon; // the current Polygon of the Linked List being iterated through
    private Vector3D light;
    
    public Converter(){
        polygons = new LinkedList<>();
    }
    
    public boolean initialize(LinkedList<String> rawData){
        boolean initialized = false;
 
        String firstLine = rawData.pollFirst();
        
        String[] split = firstLine.split(" ");
        float currentX = Float.parseFloat(split[0]);
        float currentY = Float.parseFloat(split[1]);
        float currentZ = Float.parseFloat(split[2]);
        
        light = new Vector3D(currentX,currentY,currentZ);
        
        for (String s : rawData) {
            Polygon i = StringToPolygon(s);
            initialized = polygons.add(i);
            if(!initialized){
                break;
            }
        }
        if(initialized)
            currentPolygon = polygons.pollFirst();
        
        return initialized;
    }
    
    public Vertex[] getCurrentVertices(){return currentPolygon.vertices;}
    
    public int[] getCurrentRGB(){return currentPolygon.originalRGB;}
    
    public Vector3D getLight(){return light;}
    
    public boolean hasCurrentPolygon(){return currentPolygon != null;}
    
    public void nextPolygon(){currentPolygon = polygons.pollFirst();}
    
    public Polygon StringToPolygon(String line){
        Vertex[] vertices = new Vertex[3];
        int[] rgb;
        String[] split = line.split(" ");
            
        for (int i = 0; i < 3; i++) {
            float currentX = Float.parseFloat(split[i*3]);
            float currentY = Float.parseFloat(split[(i*3)+1]);
            float currentZ = Float.parseFloat(split[(i*3)+2]);
            vertices[i] = new Vertex(currentX,currentY,currentZ); 
        }
            
        int r = Integer.parseInt(split[9]);
        int g = Integer.parseInt(split[10]);
        int b = Integer.parseInt(split[11]);
            
        rgb = new int[3];
        rgb[0] = r;
        rgb[1] = g;
        rgb[2] = b;
            
        return new Polygon(vertices,rgb);
    }
}
