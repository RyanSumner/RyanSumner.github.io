COMP261 Assignment3 - Graphics Pipeline

The Executeable Jar file does not need any arguements and runs as is.

Click the open button to open the wanted data file.
You can open a new data file at any time.

The bounding box of the data is scaled and moved to fit inside the image in the GUI, it will always be displayed in the top left corner of the image.

Rotate the image using the LEFT, RIGHT, UP and DOWN arrow keys.

Set the Viewing Direction in terms of X,Y and Z in terms of the coordinate system used by the image space (y increases down, x increases right, z increases into the image)
Setting the view resets the rotation, and resets the light direction to the default;
(The Default viewing direction is 0,0,1).

Set the Light Direction, Light Intensity and Ambient Light, in terms of rgb in the respective boxes and click to respective button to set it.
Setting the Light Direction is set according to the imagespace, AFTER the viewing direction is set (not affected by rotations)
(The default light direction is the one specified in the data file).

Default Ambient Light is all set to 0.5.
Default Light Intensity is all set to 0.5.